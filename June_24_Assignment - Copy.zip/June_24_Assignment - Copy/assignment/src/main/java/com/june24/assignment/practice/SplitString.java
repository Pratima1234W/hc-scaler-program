package com.june24.assignment.practice;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public class SplitString {
    public static void main(String[] args) {
        String str = "Capgemini";
        List<String> s = str.chars()
                .mapToObj(c -> String.valueOf((char) c))
                .collect(Collectors.toList());
        System.out.println(s);
        }
    }



