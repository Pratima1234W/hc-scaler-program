package com.june24.assignment.stringAssignment.stringBuffer;
/* Reverse the following string “This method returns the reversed object on which it was
called” using StringBuffer Class
*/
public class StringBuffer3 {
    public static void main (String[] args){
        String str = "This method returns the reversed object on which it was called";

        StringBuffer stringBuffer = new StringBuffer(str);
        stringBuffer.reverse();
        System.out.println("reversed string : " +stringBuffer);
    }
}
