package io.curd.apioperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApioperationApplicationTests {

	@Test
	void contextLoads() {
	}

}
