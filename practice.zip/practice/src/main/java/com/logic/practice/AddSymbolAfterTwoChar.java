package com.logic.practice;

import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class AddSymbolAfterTwoChar {
    public static void main(String[] args){
        String input = "Input";
        String result = IntStream.range(0, input.length())
                .filter(i -> i % 2 == 0)
                .mapToObj(i -> input.substring(i, Math.min(i + 2, input.length())) + "#")
                .collect(Collectors.joining());
        System.out.println(result);
    }
}
