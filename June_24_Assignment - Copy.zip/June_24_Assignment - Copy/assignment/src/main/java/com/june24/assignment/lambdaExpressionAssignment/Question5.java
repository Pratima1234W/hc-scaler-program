package com.june24.assignment.lambdaExpressionAssignment;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

/* create a string that consist of the first letter of each word in the list of Strings provided.
   Hint: Use Consumer interface and String Builder to construct the result *

   1.StringBuilder - not synchronized, not thread safe, Faster, use in single threaded scenario.
   2.StringBuffer - synchronized, thread safe, slower, Use in multi-threaded scenarios.
   most cases StringBuilder is the preferred choice.
 */
public class Question5 {
    public static void main(String[] args) {
        List<String> words = Arrays.asList("hello", "java", "programming", "code", "world");
        StringBuilder builder = new StringBuilder();
        Consumer<String> appendFirstLetter = word -> {
            if (!word.isEmpty()) {
                builder.append(word.charAt(0));
            }
        };
        words.forEach(appendFirstLetter);
        String result = builder.toString();

        System.out.println("final result : " + result);
    }
}
