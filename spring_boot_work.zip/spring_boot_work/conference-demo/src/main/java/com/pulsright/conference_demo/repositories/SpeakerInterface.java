package com.pulsright.conference_demo.repositories;

import com.pulsright.conference_demo.models.Speaker;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SpeakerInterface extends JpaRepository<Speaker, Long> {
}
