package com.june24.assignment.apac;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/* find those values which 3 at the 2nd position and find the average of those values

[334,214,273,637,423,384] */
public class FindAverage {
    public static void main(String[] args){
        List<Integer> list = Arrays.asList(334,214,273,637,423,384);
        List<Integer> list1 = list.stream()
                .filter(l ->l.toString().charAt(1) == '3')
                .collect(Collectors.toList());
        list1.forEach(System.out::println);

        double average = list1.stream()
                .mapToInt(Integer::intValue)
                .average()
                .orElse(0.0);
        System.out.println("average :" +average);

    }
}
