package com.june24.assignment.threadAssignment;
/* currentThread(), setPriority()- MIN_priority = 1, NOR_priority = 5, Max_Priority = 10
* - priority either can be given by JVM or programmer can give explicitly */
public class ThreadSafe implements Runnable {
    @Override
    public void run(){
        synchronized (this) {
            for (int i = 0; i < 3; i++) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("Value of i :" + i);
            }
        }
    }
    public static void main(String[] args){
        ThreadSafe obj = new ThreadSafe();
        Thread t = new Thread(obj);
        t.setName("A");

        Thread t1 = new Thread(obj);
        t.setName("B");

        Thread t2= new Thread(obj);
        t.setName("C");

        Thread t3 = new Thread(obj);
        t.setName("D");

        Thread t4 = new Thread(obj);
        t.setName("E");

        t.start();

    }

}
