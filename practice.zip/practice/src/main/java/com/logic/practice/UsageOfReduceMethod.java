package com.logic.practice;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/*reduce() : Its terminal operation in the stream API
    - used to combine the elements of stream into a single result.
    - */
public class UsageOfReduceMethod {
    public static void main(String[] args){
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        /*  //Integer. sum() is a built-in method in java that returns the sum of its arguments.
        int sum = numbers.stream()
                .reduce(0, Integer::sum);
        System.out.println(sum);*/

        /*int product = numbers.stream()
                .reduce(1, (a, b)->a*b);
        System.out.println(product);*/

        //finding longest string
        List<String> string = Arrays.asList("asdf", "long", "finding");
        /*Optional<String> longestString = string.stream()
                .reduce((a, b)-> a.length() > b.length() ? a : b);
        longestString.ifPresent(str -> System.out.println(str));*/

        //concatenating  all string in a list

        String concat = string.stream()
                .reduce("", (a, b)-> a+b);
        System.out.println(concat);
    }
}
