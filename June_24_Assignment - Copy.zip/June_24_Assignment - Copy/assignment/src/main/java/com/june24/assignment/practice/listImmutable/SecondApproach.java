package com.june24.assignment.practice.listImmutable;

public class SecondApproach {
    public static void main(String[] args){

    }
}
