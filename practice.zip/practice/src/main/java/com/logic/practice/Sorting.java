package com.logic.practice;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Sorting {
    public static void main(String[] args){
        List<Integer> integerList = Arrays.asList(5,3,4,8,10,1);
        List<Integer> sortedList = integerList.stream()
                .sorted(Comparator.reverseOrder())
                //.sorted(Comparator.naturalOrder())
               // .sorted()
                .collect(Collectors.toList());
        System.out.println(sortedList);
    }
}
