package com.june24.assignment.practice;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindDuplicateCharacterFromString {
    public static void main(String[] args){
        String str = "Pratima";
         str.chars()
                .mapToObj(c -> (char)c)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .forEach(((character, count) ->{
                    //if(count > 1){
                        System.out.println(character +" : "+count);
                    //}
                } ));
    }
}
