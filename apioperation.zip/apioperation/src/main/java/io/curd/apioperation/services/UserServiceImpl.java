package io.curd.apioperation.services;

import io.curd.apioperation.entities.User;
import io.curd.apioperation.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;

    @Override
    public User saveUser(User user) {
        return null;
    }

    @Override
    public List<User> fetchUserList() {
        return (List<User>) userRepository.findAll();
    }

    @Override
    public User updateUser(User user, Long userId) {

       /* User userObj = UserRepository.findById(userId).get();

        if(Objects.nonNull(user.getUserName()))*/
        return null;
    }

    @Override
    public void deleteUserById(User user, Long userId) {

    }

    @Override
    public User createUser(User user) {

        return null;
    }
}
