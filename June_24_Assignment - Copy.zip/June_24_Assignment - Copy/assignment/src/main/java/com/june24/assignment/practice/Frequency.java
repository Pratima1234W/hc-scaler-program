package com.june24.assignment.practice;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Frequency {
    public static void main(String[] args){
        List<String> str = Arrays.asList("pen", "pan", "pen", "pan");
        Map<String, Long> map = str.stream()
                .collect(Collectors.groupingBy(item -> item, Collectors.counting()));
        map.forEach((key, value) -> System.out.println(key +" : "+ value));
    }
}
