package com.june24.assignment.threadAssignment;

public class MyThread extends Thread{
    // If will n't override start method call super class run method.
    @Override
    public void run(){
        for(int i = 0; i<3; i++){
            System.out.println("valur of i: " +i);
        }
  }
  public static void main(String[] args){
        MyThread obj = new MyThread();
        obj.start();
  }
}
