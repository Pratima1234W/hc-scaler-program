package com.june24.assignment.stringAssignment;
/* Given a String “Java String pool refers to collection of Strings which are stored in heap
memory”, perform the following operations (Hint: all operation can be performed using
String methods)
a. Print the string to console in lowercase
b. Print the string to console in uppercase
c. Replace all ‘a’ character in the string with $ sign
d. Check if the original String contains the word “collection”
e. Check if the following String “java string pool refers to collection of strings which
are stored in heap memory” matches the original
f. If the string does not match check if there is another method which can be used to
check if the strings are equal */
public class StringOperations {
    public static void main(String args[]) {
        String str = "Java String pool refers to collection of Strings which are stored in heap \n" +
                "memory";

        System.out.println("a : " + str.toLowerCase());
        System.out.println("b : " + str.toUpperCase());
        System.out.println("c : " + str.replace('a', '$'));
        System.out.println("d : " + str.contains("collection"));
        System.out.println("e : " + str.matches("java string pool refers to collection of strings which\n" +
                "are stored in heap memory"));
       /* String str2 = "java string pool refers to collection of strings which\n" +
                "are stored in heap memory";*/
        if (str == "java string pool refers to collection of strings which\n" +
                "are stored in heap memory") {
            System.out.println("f : String match");
        }else{
            System.out.println("f : String not match");
        }
    }
}
