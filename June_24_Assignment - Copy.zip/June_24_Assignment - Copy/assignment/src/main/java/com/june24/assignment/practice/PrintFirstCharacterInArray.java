package com.june24.assignment.practice;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PrintFirstCharacterInArray {
    public static void main(String[] args){

        /* printing first character in array.

        String[] str = {"pen","pan", "pen", "pan"};
        List<Character> ch = Arrays.stream(str)
                .map(s -> s.charAt(0))
                .collect(Collectors.toList());
                System.out.println(ch);
                //.forEach(System.out::println);*/

        /* Simply printing first character from string*/

        List<String> str= Arrays.asList("apple", "pen", "NoteBook");
        str.stream()
                .map(s -> s.charAt(0))      //map each string  to its first character
                .forEach(System.out::println); //print first character
    }
}
