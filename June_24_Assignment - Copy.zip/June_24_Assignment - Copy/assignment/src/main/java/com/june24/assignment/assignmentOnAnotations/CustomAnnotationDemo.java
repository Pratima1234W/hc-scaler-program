package com.june24.assignment.assignmentOnAnotations;
/* Create a custom annotation called @Test which can be only applied on a method implying
that the following method is a test-case. (Is it possible to restrict the annotation to be
applied only on a non-static method?) */

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

public class CustomAnnotationDemo  {

    @Test(description = "This is demo test case")
    public void testMethod1(){
        //test logic
        System.out.println("Executing test method1");
    }

    @Test
    public void testMethod2(){
        System.out.println("Executing testMethod2");
    }

    @Test
    public void testMethod3(){
        System.out.println("Executing testMethod3");
    }

}
