package com.logic.practice;

import java.util.Arrays;
import java.util.OptionalDouble;

public class AverageAndSum {
    public static void main(String[] args){
        int[] number = {2, 5, 8, 6};
        OptionalDouble avg = Arrays.stream(number)
                .average();
       System.out.println(avg);
    }
}
