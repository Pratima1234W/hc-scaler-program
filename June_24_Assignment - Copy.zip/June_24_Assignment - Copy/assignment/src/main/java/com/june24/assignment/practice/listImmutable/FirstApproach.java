package com.june24.assignment.practice.listImmutable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FirstApproach {
    public static void main(String[] args){
        List<String> mutableList = new ArrayList<>();
        mutableList.add("A");
        mutableList.add("B");
        mutableList.add("C");
        mutableList.add("D");

        List<String> immutableList = Collections.unmodifiableList(mutableList);
        System.out.println(immutableList);

    }
}
