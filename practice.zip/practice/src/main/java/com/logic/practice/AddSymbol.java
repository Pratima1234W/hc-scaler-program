package com.logic.practice;

public class AddSymbol {
    public static void main(String[] args){
        String input = "INPUT";
        StringBuilder builder = new StringBuilder();

        for(char c : input.toCharArray()){
            builder.append("*").append(c).append("*");
        }
        System.out.println(builder.toString());
    }
}
