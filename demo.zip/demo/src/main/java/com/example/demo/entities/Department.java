package com.example.demo.entities;

public class Department {

    depid (int), dname (String), dfunction (String)
}
