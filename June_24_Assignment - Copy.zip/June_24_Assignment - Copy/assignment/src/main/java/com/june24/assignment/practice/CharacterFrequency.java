package com.june24.assignment.practice;


/* chars() - converts String into an IntStream
  item -> item each item is grouped by itself */
import java.util.Map;
import java.util.stream.Collectors;

public class CharacterFrequency {
    public static void main(String[] args){
        String str = "pratima";
        Map<Character, Long> map = str.chars()
                .mapToObj(c -> (char) c)
                .collect((Collectors.groupingBy(item -> item, Collectors.counting())));
        //map.forEach((key,value)-> System.out.println(key + " : " + value)); //print string
        System.out.println(map);    //print in object form
    }
}