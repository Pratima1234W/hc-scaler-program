
package com.june24.assignment.stringAssignment.stringBuffer;

/* Insert the following string “insert text” into the string “It is used to _ at the specified index
position” at the location denoted by the sign _
 */
public class StringBuffer2 {
    public static void main(String[] args) {

        String str = "It is used to _ at the specified index position";
        String str1 = "insert text";

        int indexToInsert = 15;

        String modifiedStr = str.substring(0, indexToInsert) + str1 + str.substring(indexToInsert);

        System.out.println("Original String : " + str);
        System.out.println("Modified string : " + modifiedStr);
    }

}
