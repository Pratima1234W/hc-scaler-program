package com.online.testManagementSystem.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

@Entity
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Questions {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int questionId;

    @ElementCollection
    private List<String> questionOptions;
    private String questionTitle;
    private Integer questionAnswer;
    private BigDecimal questionMarks;
    private Integer chosenAnswer;
    private BigDecimal marksScored;
}
