package com.june24.assignment.lambdaExpressionAssignment;

import java.time.LocalDateTime;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import static java.time.LocalTime.now;

/* Use the functional interface supplier, consumer, predicate & function to invoke build in methods from
   Java API(interface, collection of pre-written classes, interfaces and methods that provides set of functionalities*/
public class Question3 {
    public static void main(String[] args){
        Supplier<String> currentTimeSupplier = () -> LocalDateTime.now().toString();
        String currentTime = currentTimeSupplier.get();
        System.out.println("Current Time:" + currentTime);

        Consumer<Integer> square = num ->
            System.out.println("square of " + num + " is " + Math.pow(num, 2));
            square.accept(5);

        Predicate<String> isEmptyString = str -> str.isEmpty();
        String text = "";
        System.out.println("Is the Empty string:" +
        isEmptyString.test(text));

        Function<Integer, Integer> product = num -> num * 2;
        int number = 3;
        int result = product.apply(number);
        System.out.println("Product : " +result );
    }
}
