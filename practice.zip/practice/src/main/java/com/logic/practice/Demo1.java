package com.logic.practice;

public class Demo1 {
    public static void main(String[] args) {
        int[] numbers = {1, 10, 1, 1, 10};
        int sum = 0;
        {
            for (int number : numbers) {
                sum = sum + number;
            }
            double avg = sum / numbers.length;
            System.out.println(avg);
        }
    }
}
