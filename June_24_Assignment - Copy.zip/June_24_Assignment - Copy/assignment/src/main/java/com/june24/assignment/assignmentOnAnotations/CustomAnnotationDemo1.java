package com.june24.assignment.assignmentOnAnotations;

@Info(AuthorID = "12345", author = "John Doe", supervisor = "Smith", date = "2024-11-07",
        time = "10:30 AM", version =1, description ="This class handles data processing")

public class CustomAnnotationDemo1 {

    @Info(AuthorID = "12345", date = "2024-11-07", time = "11:00 AM",
            version =1, description ="This method processes incoming Data.")

    public void processData(){
    }

    @Info(AuthorID = "54321", date = "2024-07-12", time = "12:00 PM", version = 1,
    description = "This field stores configuration data.")
    private String configData;
}
