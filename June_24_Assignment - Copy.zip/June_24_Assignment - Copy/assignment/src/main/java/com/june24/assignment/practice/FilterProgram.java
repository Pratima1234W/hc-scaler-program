package com.june24.assignment.practice;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/*
* Filter a list of strings to find all elements that contain a specific
* substring and then sort them in reverse order?*/
public class FilterProgram {
    public static void main(String[] args){
        List<String> list = Arrays.asList("apple","banana","apricot");
        String substring = "p";
                List<String> list1 = list.stream()
                                 .filter(s -> s.contains(substring))
                        //.map(s -> s.contains(substring))
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toList());

        list1.forEach(System.out::println);
    }
}
