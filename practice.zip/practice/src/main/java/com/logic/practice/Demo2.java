package com.logic.practice;

public class Demo2 {
    public static void main(String[] arg){
        int[] input = {2, 2, 2, 1, 1};
        int sum = 0;
        for(int number : input){
            sum = sum + number;
        }
        System.out.println(sum);
        double avg = sum / input.length;
        System.out.println(avg);

    }
}
